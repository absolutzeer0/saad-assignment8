package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import java.awt.Color;
import java.awt.Container;
import java.io.File;

public class ScreenLoading extends Container
{
	private static final long serialVersionUID = 2L;
        private JLabel loadLabel;
		
	// Constructor
	public ScreenLoading(MainWindow parent, boolean isContinue)
	{
		initialize(parent);
		parent.revalidate();
                loadData(parent, isContinue);
	}
	
	// Generate the JFrame layout
	private void initialize(MainWindow parent) 
	{
		this.setSize(450,300);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{103, 242, 103};
		gridBagLayout.rowHeights = new int[]{28, 0, 0, 28, 36, 0, 0, 0};
		this.setLayout(gridBagLayout);
		
		// Loading bar label
                loadLabel = new JLabel();
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.anchor = GridBagConstraints.CENTER;
		gbc_label.gridx = 1; 
		gbc_label.gridy = 3;
		this.add(loadLabel, gbc_label);
		
		// Loading bar
		JProgressBar bar = new JProgressBar();
		bar.setBackground(Color.WHITE);
                bar.setIndeterminate(true);
		bar.setSize(236, 34);
		loadLabel.setLabelFor(bar);
		GridBagConstraints gbc_progBar = new GridBagConstraints();
		gbc_progBar.anchor = GridBagConstraints.CENTER;
		gbc_progBar.gridx = 1; 
		gbc_progBar.gridy = 4;
		this.add(bar, gbc_progBar);
		
		// Dispaly this pane in the window
		parent.setContentPane(this);
	}
        
        private void loadData(MainWindow parent, boolean isContinue)
        {
            // If continuing, use files in save directory
            String baseDir = isContinue ? parent.getGuiInterface().saveDir : "";
            
            // Load inital files
            loadLabel.setText("Loading files...");
            parent.getGuiInterface().loadFiles(baseDir);
            
            // Generate APRIORI readout
            loadLabel.setText("Generating APRIORI...");
            String apriori = 
                    parent.getGuiInterface().digestFileWithWeka(new File(baseDir+"records.csv"));
            
            parent.setContentPane(new ScreenSelectProfs(parent, apriori));
        }
	
}
